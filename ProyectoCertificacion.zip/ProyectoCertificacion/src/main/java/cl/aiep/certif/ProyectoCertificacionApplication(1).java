package cl.aiep.certif;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoCertificacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoCertificacionApplication.class, args);
	}

}
