package cl.aiep.certif;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoCertificacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
